# Run the type checker

poetry run pyright

# Run tests

poetry run pytest
