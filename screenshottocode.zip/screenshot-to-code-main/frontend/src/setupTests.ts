// So jest test runner can read env vars from .env file
import { config } from "dotenv";
config({ path: ".env.jest" });
