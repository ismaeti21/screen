export const URLS = {
  "intro-to-video":
    "https://github.com/abi/screenshot-to-code/wiki/Screen-Recording-to-Code",
  tips: "https://git.new/s5ywP0e",
};
